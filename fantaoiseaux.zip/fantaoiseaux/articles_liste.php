<!DOCTYPE html>
<html>
<head>
    <title>Liste Articles User</title>
    <meta charset="utf-8">

</head>
<body>
    <section>
        <H1>Tous les articles Fanta Oiseaux</H1>
        
        <table sumary="Tous les Articles Fanta Oiseaux">
            <caption>Articles Fanta Oiseaux</caption>
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Titre</th>
                    <th>Date De Création</th>
                    <th>Auteur</th>
                    <th>A la une ?</th>
                    <th>Modifier</th>
                    <th>Supprimer</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><img src="images/will.jpg" alt="Will Smith" title="Will Smith"></td>
                    <td>Developpeurs du terroir</td>
                    <td>2019-10-30</td>
                    <td>Jean leguin, humoriste</td>
                    <td></td>
                    <td>O</td>
                    <td>X</td>
                </tr>
                <tr>
                    <td><img src="images/will.jpg" alt="Will Smith" title="Will Smith"></td>
                    <td>Once upon a time in php</td>
                    <td>2019-10-30</td>
                    <td>Big Mc Johnson</td>
                    <td></td>
                    <td>O</td>
                    <td>X</td>
                </tr>
                <tr>
                    <td><img src="images/will.jpg" alt="Will Smith" title="Will Smith"></td>
                    <td>Jackie Chan et la fureur du java</td>
                    <td>2019-10-25</td>
                    <td>tchoun yo fat</td>
                    <td></td>
                    <td>O</td>
                    <td>X</td>
                </tr>
                <tr>
                    <td><img src="images/will.jpg" alt="Will Smith" title="Will Smith"></td>
                    <td>Html super saian</td>
                    <td>2019-10-06</td>
                    <td>Témoins de Jojoba</td>
                    <td><input type="checkbox" id="alaune" name="alaune" checked></td>
                    <td>O</td>
                    <td>X</td>
                </tr>
                <tr>
                    <td><img src="images/will.jpg" alt="Will Smith" title="Will Smith"></td>
                    <td>Marilyn Monson : Symphony for the devil</td>
                    <td>2019-10-01</td>
                    <td>Lucie Fer</td>
                    <td></td>
                    <td>O</td>
                    <td>X</td>
                </tr>
                    
                    
                    
            </tbody>
        
        </table>
            
        
        
    </section>